import Recaman.SingleWindowEquality
import Recaman.CapacityEqualityInduction

namespace Recaman.BlockSuffixPositivity

open Recaman.LeadingRunSupply
open Recaman.LineCapacityPeriodic
open Recaman.CapacityEqualityInduction
open Recaman.SingleWindowEquality
open Recaman.ShortPeriodicSupply (sign)

/-! # Suffixes of padded block words have positive rise and area

`areaW w` is the area of the oldest-first word `w` above its start level:
the sum of the masses of its nonempty prefixes. -/

def areaW : List Bool → Int
  | [] => 0
  | x :: w => sign x * ((w.length : Int) + 1) + areaW w

theorem areaW_append (u v : List Bool) :
    areaW (u ++ v) = areaW u + (v.length : Int) * mass u + areaW v := by
  induction u with
  | nil => simp [areaW]
  | cons x u ih =>
    show sign x * (((u ++ v).length : Int) + 1) + areaW (u ++ v) = _
    rw [ih, List.length_append]
    show _ = sign x * ((u.length : Int) + 1) + areaW u + _ + _
    rw [mass_cons]
    cases x <;> simp [sign] <;> grind

theorem areaW_single (x : Bool) : areaW [x] = sign x := by
  simp [areaW]

theorem mass_rep_false (j : Nat) : mass (List.replicate j false) = -(j : Int) := by
  induction j with
  | zero => rfl
  | succ j ih => rw [List.replicate_succ, mass_cons, ih]; simp [sign]; omega

/-- Every nonempty suffix has mass `≥ 1` and area `≥ 1`. -/
def SufPos (l : List Bool) : Prop :=
  ∀ u v : List Bool, u ++ v = l → v ≠ [] → 1 ≤ mass v ∧ 1 ≤ areaW v

theorem sufPos_nil : SufPos [] := by
  intro u v h hv
  exact absurd (List.append_eq_nil_iff.mp h).2 hv

theorem sufPos_of_drops (B : List Bool)
    (h : ∀ k, k < B.length → 1 ≤ mass (B.drop k) ∧ 1 ≤ areaW (B.drop k)) : SufPos B := by
  intro u v huv hv
  have hvd : v = B.drop u.length := by rw [← huv, List.drop_left]
  have hlen : u.length < B.length := by
    rw [← huv, List.length_append]
    have : v.length ≠ 0 := fun h0 => hv (List.length_eq_zero_iff.mp h0)
    omega
  rw [hvd]; exact h _ hlen

theorem sufPos_free : SufPos [true] := sufPos_of_drops _ (by decide)
theorem sufPos_aas : SufPos [false, true, true, true] := sufPos_of_drops _ (by decide)
theorem sufPos_triple :
    SufPos [false, false, true, true, true, true, false, true, true, true] :=
  sufPos_of_drops _ (by decide)

theorem sufPos_append (w B : List Bool) (hw : SufPos w) (hB : SufPos B) (hBne : B ≠ [])
    (hBa : 0 ≤ areaW B) : SufPos (w ++ B) := by
  intro u v h hv
  have hBm := (hB [] B rfl hBne).1
  rcases List.append_eq_append_iff.mp h with ⟨a', h1, h2⟩ | ⟨c', _, h2⟩
  · subst h2
    by_cases ha : a' = []
    · subst ha; exact hB [] B rfl hBne
    · obtain ⟨m1, a1⟩ := hw u a' h1.symm ha
      have hnn : 0 ≤ (B.length : Int) * mass a' :=
        Int.mul_nonneg (Int.natCast_nonneg _) (by omega)
      rw [mass_append, areaW_append]
      omega
  · exact hB c' v h2.symm hv

theorem sufPos_block {w : List Bool} (h : BlockWord w) : SufPos w := by
  induction h with
  | nil => exact sufPos_nil
  | free _ ih => exact sufPos_append _ _ ih sufPos_free (by simp) (by decide)
  | aas _ ih => exact sufPos_append _ _ ih sufPos_aas (by simp) (by decide)
  | triple _ ih => exact sufPos_append _ _ ih sufPos_triple (by simp) (by decide)

/-- **Lemma 1 (word form).** Every nonempty suffix of `β ++ A^a`, `β` a block
word, has mass `≥ 1` and area `≥ 1`. -/
theorem block_suffix_positive {β : List Bool} (hβ : BlockWord β) :
    ∀ a : Nat, SufPos (β ++ List.replicate a true)
  | 0 => by rw [List.replicate_zero, List.append_nil]; exact sufPos_block hβ
  | a+1 => by
      rw [List.replicate_succ', ← List.append_assoc]
      exact sufPos_append _ _ (block_suffix_positive hβ a) sufPos_free (by simp) (by decide)

/-! ## Walk form -/

theorem Ar_areaW (f : Nat → Bool) (t : Nat) : ∀ k : Nat, Ar f t k = areaW (seg f t k)
  | 0 => by simp [Ar, seg, areaW]
  | k+1 => by
      rw [Ar_succ, seg_succ, areaW_append, areaW_single, ← Ar_areaW f t k, seg_mass,
        show t + k + 1 = (t + k) + 1 from rfl, Fw_succ]
      simp
      omega

theorem seg_false (f : Nat → Bool) (s : Nat) :
    ∀ j : Nat, (∀ i, s ≤ i → i < s + j → f i = false) → seg f s j = List.replicate j false
  | 0, _ => by simp [seg]
  | j+1, h => by
      rw [seg_succ, seg_false f s j (fun i h1 h2 => h i h1 (by omega)), h (s+j) (by omega) (by omega),
        List.replicate_succ']

theorem suffix_split (f : Nat → Bool) (s n t : Nat) (h1 : s ≤ t) (h2 : t ≤ s + n) :
    seg f s n = seg f s (t - s) ++ seg f t (s + n - t) := by
  have := seg_add f s (t - s) (s + n - t)
  rw [show t - s + (s + n - t) = n by omega, show s + (t - s) = t by omega] at this
  exact this

/-- **Lemma 1 (walk form).** If the clocks `[s, s+n)` read `β ++ A^a` with `β`
a block word, then for every `t ∈ [s, s+n)`:
`Fw(s+n) - Fw(t) ≥ 1` and the area `Ar t (s+n-t) ≥ 1`. -/
theorem block_suffix_positive_walk (f : Nat → Bool) (s n a : Nat) {β : List Bool}
    (hβ : BlockWord β) (hseg : seg f s n = β ++ List.replicate a true)
    (t : Nat) (h1 : s ≤ t) (h2 : t < s + n) :
    1 ≤ Fw f (s + n) - Fw f t ∧ 1 ≤ Ar f t (s + n - t) := by
  have hsp := suffix_split f s n t h1 (by omega)
  rw [hseg] at hsp
  have hne : seg f t (s + n - t) ≠ [] := by
    intro h0
    have := seg_length f t (s + n - t)
    rw [h0] at this; simp at this; omega
  obtain ⟨hm, ha⟩ := block_suffix_positive hβ a _ _ hsp.symm hne
  rw [seg_mass, show t + (s + n - t) = s + n by omega] at hm
  rw [Ar_areaW]
  exact ⟨hm, ha⟩

/-! ## Lemma 1': no P2 window after an S-run -/

theorem fw_false_run (f : Nat → Bool) (t : Nat) :
    ∀ k : Nat, (∀ i, t ≤ i → i < t + k → f i = false) → Fw f (t + k) = Fw f t - k
  | 0, _ => by simp
  | k+1, h => by
      have ih := fw_false_run f t k (fun i h1 h2 => h i h1 (by omega))
      rw [show t + (k+1) = (t + k) + 1 from rfl, Fw_succ, ih, h (t+k) (by omega) (by omega)]
      simp [sign]; omega

theorem area_after_false (j : Nat) : ∀ v : List Bool, 1 ≤ areaW v → (j : Int) + 1 ≤ mass v →
    1 ≤ areaW (v ++ List.replicate j false) := by
  induction j with
  | zero => intro v h _; simpa using h
  | succ j ih =>
    intro v ha hm
    rw [List.replicate_succ, ← List.singleton_append, ← List.append_assoc]
    apply ih
    · rw [areaW_append, areaW_single]; simp [sign]; omega
    · rw [mass_append]; simp [sign]; omega

/-- **Lemma 1'.** If `[s, s+n)` reads `β ++ A^a` (`β` a block word), the clocks
`[s+n, s+n+j)` are all subtractions, then no P2 window starting at or after `s`
ends at `s+n+j`. -/
theorem no_window_after_S_run (f : Nat → Bool) (s n a j : Nat) {β : List Bool}
    (hβ : BlockWord β) (hseg : seg f s n = β ++ List.replicate a true)
    (hS : ∀ i, s + n ≤ i → i < s + n + j → f i = false) :
    ¬ EndN f s (s + n + j) := by
  rintro ⟨_, t, k, hst, htk, hk0, hF, hAr⟩
  by_cases ht : s + n ≤ t
  · have := fw_false_run f t k (fun i h1 h2 => hS i (by omega) (by omega))
    omega
  · have hsp := suffix_split f s n t hst (by omega)
    rw [hseg] at hsp
    have hne : seg f t (s + n - t) ≠ [] := by
      intro h0
      have := seg_length f t (s + n - t)
      rw [h0] at this; simp at this; omega
    obtain ⟨hm, ha⟩ := block_suffix_positive hβ a _ _ hsp.symm hne
    have hk : k = (s + n - t) + j := by omega
    have hsk : seg f t k = seg f t (s + n - t) ++ List.replicate j false := by
      rw [hk, seg_add, show t + (s + n - t) = s + n by omega,
        seg_false f (s + n) j hS]
    have hmass : mass (seg f t k) = 1 := by
      rw [seg_mass]; omega
    rw [hsk, mass_append, mass_rep_false] at hmass
    have hpos := area_after_false j _ ha (by omega)
    rw [← hsk, ← Ar_areaW] at hpos
    omega

/-- Lemma 1' on integer clocks: `[p, p+n)` reads `β ++ A^a`, `[p+n, p+n+j)` is
an S-run; then `p+n+j` is not endable from `p`. -/
theorem no_endable_after_S_run (e : Int → Bool) (p : Int) (n a j : Nat) {β : List Bool}
    (hβ : BlockWord β) (hseg : segment e p n = β ++ List.replicate a true)
    (hS : ∀ i : Nat, i < j → e (p + ((n + i : Nat) : Int)) = false) :
    ¬ Endable e p (p + ((n + j : Nat) : Int)) := by
  have hp0 : p = p + ((0 : Nat) : Int) := by simp
  rw [endable_iff e p p _ 0 (n + j) hp0 rfl]
  rw [segment_seg e p p 0 hp0] at hseg
  have := no_window_after_S_run (fun i => e (p + (i : Int))) 0 n a j hβ hseg
    (fun i h1 h2 => by
      have := hS (i - n) (by omega)
      rwa [show n + (i - n) = i by omega] at this)
  rwa [Nat.zero_add] at this

/-! ## TS1: an endable clock after an S-run forces strict slack -/

/-- **TS1.** Assume line capacity on `[p, p+m)` and the equality-class property
for every `m ≤ n`. If `[p+n, p+n+j)` is an S-run and `p+n+j` is endable from
`p`, then `[p, p+n)` has strictly more subtractions than endable clocks. -/
theorem ts_one (e : Int → Bool) (p : Int) (n j : Nat)
    (hH : ∀ m, m ≤ n → HCap e p m) (hE : ∀ m, m ≤ n → EqClassW e p m)
    (hS : ∀ i : Nat, i < j → e (p + ((n + i : Nat) : Int)) = false)
    (hb : Endable e p (p + ((n + j : Nat) : Int))) :
    endableCount e p n + 1 ≤ subtractionCount e p n := by
  apply Classical.byContradiction
  intro hneg
  have hle : subtractionCount e p n ≤ endableCount e p n := by omega
  obtain ⟨m', hm'le, hm'mark, hm'none⟩ := last_mark (Endable e p) p n
  have hEq : endableCount e p n = endableCount e p m' := by
    have h := @countP_add (Endable e p) (classDec _) p m' (n - m')
    rw [Nat.add_sub_cancel' hm'le] at h
    have h0 : @countP (Endable e p) (classDec _) (p + m') (n - m') = 0 := by
      apply @countP_eq_zero_of (Endable e p) (classDec _)
      intro i hi
      have := hm'none (m' + i) (by omega) (by omega)
      rwa [show p + ((m' + i : Nat) : Int) = p + (m' : Int) + (i : Int) by omega] at this
    show @countP (Endable e p) (classDec _) p n = @countP (Endable e p) (classDec _) p m'
    rw [h, h0, Nat.add_zero]
  have hSadd : subtractionCount e p n =
      subtractionCount e p m' + subtractionCount e (p + m') (n - m') := by
    have h := countP_add (fun c => e c = false) p m' (n - m')
    rw [Nat.add_sub_cancel' hm'le] at h
    exact h
  have hHm' : endableCount e p m' ≤ subtractionCount e p m' := hH m' hm'le
  have htail0 : subtractionCount e (p + m') (n - m') = 0 := by omega
  have hall := not_of_countP_eq_zero _ (p + m') (n - m') htail0
  have hseg : segment e p n = segment e p m' ++ List.replicate (n - m') true := by
    rw [← segment_true e (p + m') (n - m') (fun i hi => by
      have := hall i hi
      cases h : e (p + (m' : Int) + (i : Int))
      · exact absurd h this
      · rfl)]
    rw [← segment_add, Nat.add_sub_cancel' hm'le]
  have hBW : BlockWord (segment e p m') := by
    by_cases h0 : m' = 0
    · subst h0; exact BlockWord.nil
    · rcases hm'mark with h0' | hmk
      · exact absurd h0' h0
      · exact hE m' hm'le (by omega) (by omega) hmk
  exact no_endable_after_S_run e p n (n - m') j hBW hseg hS hb

/-! ## Low clocks after a padded block prefix

The lower bound `m` need not be attained. This is the running-minimum
exclusion used in the C1 area argument; it does not prove that argument's
remaining area inequality. -/

theorem area_nondecreasing_tail (f : Nat → Bool) (t n : Nat) : ∀ j : Nat,
    (∀ i, n < i → i ≤ n + j → Fw f t ≤ Fw f (t + i)) →
    Ar f t n ≤ Ar f t (n + j)
  | 0, _ => by simp
  | j+1, h => by
      have ih := area_nondecreasing_tail f t n j (fun i hi hle => h i hi (by omega))
      have hlast := h (n + j + 1) (by omega) (by omega)
      rw [show n + (j + 1) = n + j + 1 from rfl, Ar_succ]
      have heq : t + (n + j) + 1 = t + (n + j + 1) := by omega
      rw [heq]
      omega

/-- A supplied clock after a padded block prefix is at least two levels above
every lower bound on the intervening walk. The prefix and the tail are both
about the same sign string; no capacity or equality conjecture is assumed. -/
theorem block_prefix_low_clock_not_endable (f : Nat → Bool) (n a b : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true)
    (hnb : n ≤ b) (m : Int)
    (hmin : ∀ u, n ≤ u → u ≤ b → m ≤ Fw f u)
    (hlow : Fw f b ≤ m + 1) : ¬ EndN f 0 b := by
  rintro ⟨_, t, k, _, htk, hk, hF, hAr⟩
  rw [htk] at hF
  have htm : Fw f t ≤ m := by omega
  by_cases htn : t < n
  · obtain ⟨_, hpos⟩ := block_suffix_positive_walk f 0 n a hβ hseg t
      (Nat.zero_le t) (by omega)
    simp only [Nat.zero_add] at hpos
    have hnk : n - t ≤ k := by omega
    have hext := area_nondecreasing_tail f t (n - t) (k - (n - t)) (by
      intro i hi hle
      have hlo := hmin (t + i) (by omega) (by omega)
      omega)
    rw [show n - t + (k - (n - t)) = k by omega] at hext
    omega
  · have hbase := hmin t (by omega) (by omega)
    have hge := area_ge f t k (by
      intro i hi hle
      have hlo := hmin (t + i) (by omega) (by omega)
      omega)
    rw [htk] at hge
    omega

theorem two_marks_le_count (P : Nat → Prop) (s u v : Nat) : ∀ j : Nat,
    s ≤ u → u < v → v < s + j → P u → P v → 2 ≤ cN P s j
  | 0, hsu, huv, hv, _, _ => by omega
  | j+1, hsu, huv, hv, hpu, hpv => by
      classical
      by_cases hvj : v < s + j
      · have ih := two_marks_le_count P s u v j hsu huv hvj hpu hpv
        by_cases hp : P (s+j)
        · rw [cN_succ_pos P s j hp]; omega
        · rw [cN_succ_neg P s j hp]; exact ih
      · have hveq : v = s + j := by omega
        have hpos : 1 ≤ cN P s j := by
          apply Classical.byContradiction
          intro h
          have hz : cN P s j = 0 := by omega
          exact not_of_cN_zero P s j hz u hsu (by omega) hpu
        have hp : P (s+j) := by simpa [hveq] using hpv
        rw [cN_succ_pos P s j hp]
        omega

/-- Recovering two levels from a low visit forces two distinct nonsupplied A
clocks after that visit. Both are nonsupplied with respect to the original
left endpoint, rather than a rebased interval. -/
theorem two_nonsupplied_additions_of_recovery (f : Nat → Bool) (n a r b : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true)
    (hnr : n ≤ r) (hrb : r ≤ b) (m : Int) (hr : Fw f r = m)
    (hmin : ∀ u, n ≤ u → u ≤ b → m ≤ Fw f u)
    (hhigh : m + 2 ≤ Fw f b) :
    ∃ u v, r ≤ u ∧ u < v ∧ v < b ∧
      Fw f u = m ∧ Fw f v = m + 1 ∧
      f u = true ∧ ¬ EndN f 0 u ∧ f v = true ∧ ¬ EndN f 0 v := by
  obtain ⟨v, hrv, hvb, hv, hvA⟩ := ivt f b (m+2) hhigh (b-r) r (by omega) (by omega)
  obtain ⟨u, hru, huv, hu, huA⟩ := ivt f v (m+1) (by omega) (v-r) r (by omega) (by omega)
  have hnu := block_prefix_low_clock_not_endable f n a u hβ hseg (by omega) m
    (fun i hni hiu => hmin i hni (by omega)) (by omega)
  have hnv := block_prefix_low_clock_not_endable f n a v hβ hseg (by omega) m
    (fun i hni hiv => hmin i hni (by omega)) (by omega)
  exact ⟨u, v, hru, huv, hvb, by omega, by omega, huA, hnu, hvA, hnv⟩

theorem shifted_area_nonneg (f : Nat → Bool) (t : Nat) (level : Int) : ∀ k : Nat,
    (∀ i, 1 ≤ i → i ≤ k → level - 1 ≤ Fw f (t+i)) →
    0 ≤ Ar f t k + (k : Int) * (Fw f t - level + 1)
  | 0, _ => by simp [Ar]
  | k+1, h => by
      have ih := shifted_area_nonneg f t level k (fun i hi hle => h i hi (by omega))
      have hlast := h (k+1) (by omega) (by omega)
      rw [Ar_succ]
      push_cast
      have heq : t + k + 1 = t + (k+1) := by omega
      rw [heq]
      grind

/-- The C1 area inequality holds if the walk visits a lower bound after q0
and there is at most one nonsupplied A from q0 to b. In particular this covers
the case when a minimum of the entire tail is attained after q0. It leaves
the case of an older minimum open. -/
theorem area_nonneg_of_fresh_low_visit (f : Nat → Bool) (n a q0 r b : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true)
    (hnq : n ≤ q0) (hqr : q0 ≤ r) (hrb : r ≤ b)
    (m : Int) (hr : Fw f r = m)
    (hmin : ∀ u, n ≤ u → u ≤ b → m ≤ Fw f u)
    (hbudget : cN (fun u => f u = true ∧ ¬ EndN f 0 u) q0 (b-q0) ≤ 1) :
    0 ≤ Ar f n (b-n) + ((b-n : Nat) : Int) * (Fw f n - Fw f b + 1) := by
  have htop : Fw f b ≤ m + 1 := by
    apply Classical.byContradiction
    intro h
    obtain ⟨u, v, hru, huv, hvb, _, _, huA, hnu, hvA, hnv⟩ :=
      two_nonsupplied_additions_of_recovery f n a r b hβ hseg (by omega) hrb m hr hmin (by omega)
    have htwo := two_marks_le_count (fun u => f u = true ∧ ¬ EndN f 0 u)
      q0 u v (b-q0) (by omega) huv (by omega) ⟨huA, hnu⟩ ⟨hvA, hnv⟩
    omega
  exact shifted_area_nonneg f n (Fw f b) (b-n) (by
    intro i hi hle
    have hm := hmin (n+i) (by omega) (by omega)
    omega)

open Classical in
/-- Integer-clock form, with nonsupplied A clocks counted from the original
left endpoint p throughout. The area uses the walk translated to p. -/
theorem area_nonneg_of_fresh_low_visit_int (e : Int → Bool) (p : Int)
    (n a q0 r b : Nat) {β : List Bool} (hβ : BlockWord β)
    (hseg : segment e p n = β ++ List.replicate a true)
    (hnq : n ≤ q0) (hqr : q0 ≤ r) (hrb : r ≤ b)
    (m : Int) (hr : Fw (fun i => e (p + (i : Int))) r = m)
    (hmin : ∀ u, n ≤ u → u ≤ b → m ≤ Fw (fun i => e (p + (i : Int))) u)
    (hbudget : countP (fun c => e c = true ∧ ¬ Endable e p c)
      (p + (q0 : Int)) (b-q0) ≤ 1) :
    0 ≤ Ar (fun i => e (p + (i : Int))) n (b-n) +
      ((b-n : Nat) : Int) *
        (Fw (fun i => e (p + (i : Int))) n - Fw (fun i => e (p + (i : Int))) b + 1) := by
  classical
  have hp0 : p = p + ((0 : Nat) : Int) := by simp
  rw [segment_seg e p p 0 hp0] at hseg
  have hb := countP_cN (fun c => e c = true ∧ ¬ Endable e p c)
    p (p + (q0 : Int)) q0 rfl (b-q0)
  rw [hb] at hbudget
  have hc := cN_congr
    (fun i => e (p + (i : Int)) = true ∧ ¬ Endable e p (p + (i : Int)))
    (fun i => e (p + (i : Int)) = true ∧ ¬ EndN (fun j => e (p + (j : Int))) 0 i)
    q0 (b-q0) (by
      intro i _ _
      rw [endable_iff e p p (p + (i : Int)) 0 i hp0 rfl])
  rw [hc] at hbudget
  exact area_nonneg_of_fresh_low_visit (fun i => e (p + (i : Int))) n a q0 r b
    hβ hseg hnq hqr hrb m hr hmin hbudget

/-! ## Exact old-history trimming under a depth bound -/

/-- A padded block suffix of mass r has length at most 5r/2. -/
theorem block_prefix_suffix_length_bound (f : Nat → Bool) (n a t : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true) (htn : t ≤ n) :
    2 * ((n-t : Nat) : Int) ≤ 5 * (Fw f n - Fw f t) := by
  have hdense := dense_pad hβ a
  rw [← hseg] at hdense
  have hsplit := suffix_split f 0 n t (Nat.zero_le _) (by omega)
  simp only [Nat.zero_add, Nat.sub_zero] at hsplit
  have hd := hdense (seg f 0 t) (seg f t (n-t)) hsplit.symm
  have hm := mass_cntF (seg f t (n-t))
  rw [seg_mass, show t + (n-t) = n by omega] at hm
  have hl := seg_length f t (n-t)
  rw [hl] at hm hd
  omega

/-- No endpoint whose height is at least g-D needs a start more than
5(D+1)/2 clocks before the end of a padded block prefix. This equivalence
preserves every actual supply clock, including windows of arbitrary lag. -/
theorem endable_iff_trimmed_block_prefix (f : Nat → Bool) (n a s b D : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true)
    (hsn : s ≤ n) (_hnb : n ≤ b)
    (hlevel : Fw f n - (D : Int) ≤ Fw f b)
    (hradius : 5 * ((D : Int) + 1) < 2 * (((n-s : Nat) : Int) + 1)) :
    EndN f 0 b ↔ EndN f s b := by
  constructor
  · rintro ⟨hA, t, k, _, htk, hk, hF, hAr⟩
    have hst : s ≤ t := by
      apply Classical.byContradiction
      intro h
      have ht : t ≤ n := by omega
      have hbnd := block_prefix_suffix_length_bound f n a t hβ hseg ht
      rw [htk] at hF
      omega
    exact ⟨hA, t, k, hst, htk, hk, hF, hAr⟩
  · exact end_mono f 0 s b (Nat.zero_le s)

/-- The density bound and mass parity improve the depth-four radius to 11. -/
theorem block_prefix_suffix_length_le_eleven (f : Nat → Bool) (n a t : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true) (htn : t ≤ n)
    (hmass : Fw f n - Fw f t ≤ 5) : n-t ≤ 11 := by
  have hbnd := block_prefix_suffix_length_bound f n a t hβ hseg htn
  have hm := mass_cntF (seg f t (n-t))
  rw [seg_mass, show t + (n-t) = n by omega, seg_length] at hm
  omega

/-- Exact history reduction at depth four. Starts before s can be discarded
when at least the last 11 clocks of the padded block prefix remain. -/
theorem endable_iff_last_eleven_of_depth_four (f : Nat → Bool) (n a s b : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true)
    (hsn : s ≤ n) (_hnb : n ≤ b) (hwidth : 11 ≤ n-s)
    (hlevel : Fw f n - 4 ≤ Fw f b) : EndN f 0 b ↔ EndN f s b := by
  constructor
  · rintro ⟨hA, t, k, _, htk, hk, hF, hAr⟩
    have hst : s ≤ t := by
      apply Classical.byContradiction
      intro h
      rw [htk] at hF
      have hbnd := block_prefix_suffix_length_le_eleven f n a t hβ hseg
        (by omega) (by omega)
      omega
    exact ⟨hA, t, k, hst, htk, hk, hF, hAr⟩
  · exact end_mono f 0 s b (Nat.zero_le s)

theorem block_append {u v : List Bool} (hu : BlockWord u) (hv : BlockWord v) :
    BlockWord (u ++ v) := by
  induction hv with
  | nil => simpa using hu
  | free _ ih => simpa [List.append_assoc] using BlockWord.free ih
  | aas _ ih => simpa [List.append_assoc] using BlockWord.aas ih
  | triple _ ih => simpa [List.append_assoc] using BlockWord.triple ih

theorem block_replicate_A : ∀ j : Nat, BlockWord (List.replicate j true)
  | 0 => BlockWord.nil
  | j+1 => by
      rw [List.replicate_succ']
      exact BlockWord.free (block_replicate_A j)

theorem block_drop_free (k : Nat) : BlockWord (([true] : List Bool).drop k) := by
  cases k with
  | zero => exact BlockWord.free BlockWord.nil
  | succ k => simp; exact BlockWord.nil

theorem block_drop_aas (k : Nat) : BlockWord (aasW.drop k) := by
  have hk : k = 0 ∨ k = 1 ∨ k = 2 ∨ k = 3 ∨ 4 ≤ k := by omega
  rcases hk with rfl | rfl | rfl | rfl | hk
  · exact BlockWord.aas BlockWord.nil
  · exact block_replicate_A 3
  · exact block_replicate_A 2
  · exact block_replicate_A 1
  · have hz : aasW.drop k = [] := List.drop_eq_nil_iff.mpr (by simpa [aasW] using hk)
    rw [hz]; exact BlockWord.nil

theorem block_drop_triple (k : Nat) : BlockWord (tripW.drop k) := by
  have hk : k = 0 ∨ k = 1 ∨ k = 2 ∨ k = 3 ∨ k = 4 ∨ k = 5 ∨
      k = 6 ∨ k = 7 ∨ k = 8 ∨ k = 9 ∨ 10 ≤ k := by omega
  rcases hk with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | hk
  · exact BlockWord.triple BlockWord.nil
  · exact BlockWord.aas (BlockWord.free (BlockWord.aas BlockWord.nil))
  · exact BlockWord.aas (block_replicate_A 4)
  · exact BlockWord.aas (block_replicate_A 3)
  · exact BlockWord.aas (block_replicate_A 2)
  · exact BlockWord.aas (block_replicate_A 1)
  · exact BlockWord.aas BlockWord.nil
  · exact block_replicate_A 3
  · exact block_replicate_A 2
  · exact block_replicate_A 1
  · have hz : tripW.drop k = [] := List.drop_eq_nil_iff.mpr (by simpa [tripW] using hk)
    rw [hz]; exact BlockWord.nil

theorem block_suffix_append (w B : List Bool)
    (hw : ∀ u v, u ++ v = w → BlockWord v)
    (hB : ∀ k, BlockWord (B.drop k)) :
    ∀ u v, u ++ v = w ++ B → BlockWord v := by
  intro u v h
  rcases List.append_eq_append_iff.mp h with ⟨a', h1, h2⟩ | ⟨c', _, h2⟩
  · rw [h2]
    have hfull : BlockWord B := by simpa using hB 0
    exact block_append (hw u a' h1.symm) hfull
  · have hv : v = B.drop c'.length := by rw [h2, List.drop_left]
    rw [hv]
    exact hB _

/-- The block-word language is closed under arbitrary suffixes. -/
theorem block_suffix {w : List Bool} (hw : BlockWord w) :
    ∀ u v : List Bool, u ++ v = w → BlockWord v := by
  induction hw with
  | nil =>
      intro u v h
      have hv := (List.append_eq_nil_iff.mp h).2
      rw [hv]; exact BlockWord.nil
  | free _ ih => exact block_suffix_append _ _ ih block_drop_free
  | aas _ ih => exact block_suffix_append _ _ ih block_drop_aas
  | triple _ ih => exact block_suffix_append _ _ ih block_drop_triple

/-- Every W-clock suffix of a block word is itself a block word, so old
contexts have representatives of length exactly W. -/
theorem block_suffix_representative (W : Nat) {w : List Bool}
    (hw : BlockWord w) (hW : W ≤ w.length) :
    ∃ u v : List Bool, w = u ++ v ∧ BlockWord v ∧ v.length = W := by
  let u := w.take (w.length-W)
  let v := w.drop (w.length-W)
  have heq : u ++ v = w := List.take_append_drop _ _
  exact ⟨u, v, heq.symm, block_suffix hw u v heq, by simp [v]; omega⟩

/-! ## Quadratic area retained by the old block prefix -/

/-- A mass-sensitive lower bound, sharper than positive area alone. -/
theorem block_area_quadratic_lower {w : List Bool} (hw : BlockWord w) :
    mass w * (mass w + 1) ≤ 2 * areaW w + 2 := by
  induction hw with
  | nil => decide
  | @free w hw ih =>
      rw [areaW_append, mass_append]
      change (mass w + 1) * (mass w + 1 + 1) ≤
        2 * (areaW w + 1 * mass w + 1) + 2
      grind
  | @aas w hw ih =>
      rcases block_mass hw with he | hm
      · subst w; decide
      · rw [areaW_append, mass_append]
        change (mass w + 2) * (mass w + 2 + 1) ≤
          2 * (areaW w + 4 * mass w + 2) + 2
        grind
  | @triple w hw ih =>
      rcases block_mass hw with he | hm
      · subst w; decide
      · rw [areaW_append, mass_append]
        change (mass w + 4) * (mass w + 4 + 1) ≤
          2 * (areaW w + 10 * mass w + 9) + 2
        grind

/-- The additive constant 2 is sharp at every mass at least 2. -/
theorem block_area_quadratic_sharp (j : Nat) :
    2 * areaW (aasW ++ List.replicate j true) + 2 =
      mass (aasW ++ List.replicate j true) * (mass (aasW ++ List.replicate j true) + 1) := by
  induction j with
  | zero => decide
  | succ j ih =>
      rw [List.replicate_succ', ← List.append_assoc,
        areaW_append (aasW ++ List.replicate j true) [true],
        mass_append (aasW ++ List.replicate j true) [true]]
      change 2 * (areaW (aasW ++ List.replicate j true) +
          1 * mass (aasW ++ List.replicate j true) + 1) + 2 =
        (mass (aasW ++ List.replicate j true) + 1) *
          (mass (aasW ++ List.replicate j true) + 1 + 1)
      grind

theorem triple_area_quadratic_sharp (j : Nat) :
    2 * areaW (tripW ++ List.replicate j true) + 2 =
      mass (tripW ++ List.replicate j true) * (mass (tripW ++ List.replicate j true) + 1) := by
  induction j with
  | zero => decide
  | succ j ih =>
      rw [List.replicate_succ', ← List.append_assoc,
        areaW_append (tripW ++ List.replicate j true) [true],
        mass_append (tripW ++ List.replicate j true) [true]]
      change 2 * (areaW (tripW ++ List.replicate j true) +
          1 * mass (tripW ++ List.replicate j true) + 1) + 2 =
        (mass (tripW ++ List.replicate j true) + 1) *
          (mass (tripW ++ List.replicate j true) + 1 + 1)
      grind

/-- The extremal prefix area has exactly two block shapes, followed only by A. -/
theorem block_area_quadratic_equality {w : List Bool} (hw : BlockWord w) :
    (2 * areaW w + 2 = mass w * (mass w + 1)) ↔
      ∃ j : Nat, w = aasW ++ List.replicate j true ∨ w = tripW ++ List.replicate j true := by
  constructor
  · induction hw with
    | nil => intro he; contradiction
    | @free w hw ih =>
        intro he
        have hprev : 2 * areaW w + 2 = mass w * (mass w + 1) := by
          rw [areaW_append, mass_append] at he
          change 2 * (areaW w + 1 * mass w + 1) + 2 =
            (mass w + 1) * (mass w + 1 + 1) at he
          grind
        obtain ⟨j, hj | hj⟩ := ih hprev
        · refine ⟨j+1, Or.inl ?_⟩
          rw [hj, List.replicate_succ', List.append_assoc]
        · refine ⟨j+1, Or.inr ?_⟩
          rw [hj, List.replicate_succ', List.append_assoc]
    | @aas w hw ih =>
        intro he
        rcases block_mass hw with hz | hm
        · subst w
          exact ⟨0, Or.inl rfl⟩
        · have hb := block_area_quadratic_lower hw
          rw [areaW_append, mass_append] at he
          change 2 * (areaW w + 4 * mass w + 2) + 2 =
            (mass w + 2) * (mass w + 2 + 1) at he
          grind
    | @triple w hw ih =>
        intro he
        rcases block_mass hw with hz | hm
        · subst w
          exact ⟨0, Or.inr rfl⟩
        · have hb := block_area_quadratic_lower hw
          rw [areaW_append, mass_append] at he
          change 2 * (areaW w + 10 * mass w + 9) + 2 =
            (mass w + 4) * (mass w + 4 + 1) at he
          grind
  · rintro ⟨j, hj | hj⟩
    · rw [hj]; exact block_area_quadratic_sharp j
    · rw [hj]; exact triple_area_quadratic_sharp j

/-- The actual prefix area of any older start has the same quadratic bound.
It supplies a stronger input to the old-minimum case without assuming Q. -/
theorem block_prefix_area_quadratic_lower (f : Nat → Bool) (n a t : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true) (htn : t ≤ n) :
    (Fw f n - Fw f t) * (Fw f n - Fw f t + 1) ≤ 2 * Ar f t (n-t) + 2 := by
  have hfull : BlockWord (seg f 0 n) := by
    rw [hseg]
    exact block_append hβ (block_replicate_A a)
  have hsplit := suffix_split f 0 n t (Nat.zero_le _) (by omega)
  simp only [Nat.zero_add, Nat.sub_zero] at hsplit
  have hsuffix := block_suffix hfull (seg f 0 t) (seg f t (n-t)) hsplit.symm
  have hbound := block_area_quadratic_lower hsuffix
  simpa only [← Ar_areaW, seg_mass, show t + (n-t) = n by omega] using hbound

theorem area_split_at (f : Nat → Bool) (t n b : Nat) (htn : t ≤ n) (hnb : n ≤ b) :
    Ar f t (b-t) = Ar f t (n-t) + Ar f n (b-n) +
      ((b-n : Nat) : Int) * (Fw f n - Fw f t) := by
  have hsplit := suffix_split f t (b-t) n htn (by omega)
  rw [show t + (b-t) = b by omega] at hsplit
  rw [Ar_areaW, hsplit, areaW_append, ← Ar_areaW, ← Ar_areaW, seg_length, seg_mass,
    show t + (n-t) = n by omega]
  omega

/-- Any actual P2 window starting in the old block prefix forces a
mass-dependent negative area after that prefix. This is a necessary
condition on such a window, not its unconditional exclusion. -/
theorem old_window_area_upper (f : Nat → Bool) (n a t b : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true)
    (htn : t ≤ n) (hnb : n ≤ b) (hwin : Win f t (b-t)) :
    2 * (Ar f n (b-n) + ((b-n : Nat) : Int) * (Fw f n - Fw f b + 1)) ≤
      2 - (Fw f n - Fw f b + 1) * (Fw f n - Fw f b + 1 + 1) := by
  have hprefix := block_prefix_area_quadratic_lower f n a t hβ hseg htn
  have hsplit := area_split_at f t n b htn hnb
  obtain ⟨_, hF, hzero⟩ := hwin
  rw [show t + (b-t) = b by omega] at hF
  have htlevel : Fw f t = Fw f b - 1 := by omega
  rw [htlevel] at hprefix hsplit
  grind

/-- Over a finite tail, the earliest older window start gives one common
block-prefix representative of mass at most D+1. Every tail supply clock is
preserved. Deficit of the deleted prefix is intentionally not asserted. -/
theorem endable_tail_mass_representative (f : Nat → Bool) (n a B D : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true)
    (hmin : ∀ b, n ≤ b → b < B → Fw f n - (D : Int) ≤ Fw f b) :
    ∃ s : Nat, s ≤ n ∧ BlockWord (seg f s (n-s)) ∧
      (s = n ∨ (1 ≤ Fw f n - Fw f s ∧ Fw f n - Fw f s ≤ (D : Int)+1)) ∧
      ∀ b, n ≤ b → b < B → (EndN f 0 b ↔ EndN f s b) := by
  classical
  let P : Nat → Prop := fun t => t < n ∧
    ∃ b, n ≤ b ∧ b < B ∧ f b = true ∧ Win f t (b-t)
  have hfull : BlockWord (seg f 0 n) := by
    rw [hseg]
    exact block_append hβ (block_replicate_A a)
  by_cases hex : ∃ t, P t
  · obtain ⟨t, ht⟩ := hex
    obtain ⟨s, hsn, hsP, hfirst⟩ := first_mark P n ⟨t, by have := ht.1; omega, ht⟩
    obtain ⟨hslt, b, hnb, hbB, _, hw⟩ := hsP
    have hsplit := suffix_split f 0 n s (Nat.zero_le _) (by omega)
    simp only [Nat.zero_add, Nat.sub_zero] at hsplit
    have hsword := block_suffix hfull (seg f 0 s) (seg f s (n-s)) hsplit.symm
    have hpos := (block_suffix_positive_walk f 0 n a hβ hseg s (Nat.zero_le _) (by omega)).1
    simp only [Nat.zero_add] at hpos
    have hlevel := hw.2.1
    rw [show s + (b-s) = b by omega] at hlevel
    have hlo := hmin b hnb hbB
    refine ⟨s, hsn, hsword, Or.inr ⟨hpos, by omega⟩, ?_⟩
    intro u hnu huB
    constructor
    · rintro ⟨hA, t, k, _, htk, hwin⟩
      have hst : s ≤ t := by
        apply Classical.byContradiction
        intro h
        have hPt : P t := by
          refine ⟨by omega, u, hnu, huB, hA, ?_⟩
          have heq : k = u-t := by omega
          simpa only [heq] using hwin
        exact hfirst t (by omega) hPt
      exact ⟨hA, t, k, hst, htk, hwin⟩
    · exact end_mono f 0 s u (Nat.zero_le _)
  · refine ⟨n, Nat.le_refl _, ?_, Or.inl rfl, ?_⟩
    · simpa [seg] using BlockWord.nil
    · intro u hnu huB
      constructor
      · rintro ⟨hA, t, k, _, htk, hwin⟩
        have hnt : n ≤ t := by
          apply Classical.byContradiction
          intro h
          apply hex
          refine ⟨t, by omega, u, hnu, huB, hA, ?_⟩
          have heq : k = u-t := by omega
          simpa only [heq] using hwin
        exact ⟨hA, t, k, hnt, htk, hwin⟩
      · exact end_mono f 0 n u (Nat.zero_le _)

theorem block_mass_nonnegative {w : List Bool} (hw : BlockWord w) : 0 ≤ mass w := by
  rcases block_mass hw with rfl | hm
  · decide
  · omega

theorem block_mass_one {w : List Bool} (hw : BlockWord w) (hm : mass w = 1) : w = [true] := by
  rcases block_first hw with he | ⟨v, hv, he | he | he⟩
  · subst w; simp [mass] at hm
  · rw [he, mass_append] at hm
    change 1 + mass v = 1 at hm
    rcases block_mass hv with hz | hpos
    · rw [hz] at he; simpa using he
    · omega
  · have hv0 := block_mass_nonnegative hv
    rw [he, mass_append] at hm
    have hb : mass aasW = 2 := by decide
    rw [hb] at hm
    omega
  · have hv0 := block_mass_nonnegative hv
    rw [he, mass_append] at hm
    have hb : mass tripW = 4 := by decide
    rw [hb] at hm
    omega

theorem block_mass_two {w : List Bool} (hw : BlockWord w) (hm : mass w = 2) :
    w = [true, true] ∨ w = aasW := by
  rcases block_first hw with he | ⟨v, hv, he | he | he⟩
  · subst w; simp [mass] at hm
  · rw [he, mass_append] at hm
    change 1 + mass v = 2 at hm
    have hv1 := block_mass_one hv (by omega)
    left; rw [he, hv1]; rfl
  · rw [he, mass_append] at hm
    have hb : mass aasW = 2 := by decide
    rw [hb] at hm
    rcases block_mass hv with hz | hpos
    · right; rw [he, hz]; simp
    · omega
  · have hv0 := block_mass_nonnegative hv
    rw [he, mass_append] at hm
    have hb : mass tripW = 4 := by decide
    rw [hb] at hm
    omega

/-- A uniform quadratic upper envelope for every old block-prefix area. -/
theorem block_area_quadratic_upper {w : List Bool} (hw : BlockWord w) :
    4 * areaW w ≤ 5 * mass w * mass w - 11 * mass w + 16 := by
  induction hw with
  | nil => decide
  | @free w hw ih =>
      rcases block_mass hw with hz | hm
      · subst w; decide
      · by_cases h1 : mass w = 1
        · rw [block_mass_one hw h1]; decide
        · have hm2 : 2 ≤ mass w := by omega
          rw [areaW_append, mass_append]
          change 4 * (areaW w + 1 * mass w + 1) ≤
            5 * (mass w + 1) * (mass w + 1) - 11 * (mass w + 1) + 16
          grind
  | @aas w hw ih =>
      rcases block_mass hw with hz | hm
      · subst w; decide
      · by_cases h1 : mass w = 1
        · rw [block_mass_one hw h1]; decide
        · by_cases h2 : mass w = 2
          · rcases block_mass_two hw h2 with he | he <;> rw [he] <;> decide
          · have hm3 : 3 ≤ mass w := by omega
            rw [areaW_append, mass_append]
            change 4 * (areaW w + 4 * mass w + 2) ≤
              5 * (mass w + 2) * (mass w + 2) - 11 * (mass w + 2) + 16
            grind
  | @triple w hw ih =>
      rw [areaW_append, mass_append]
      change 4 * (areaW w + 10 * mass w + 9) ≤
        5 * (mass w + 4) * (mass w + 4) - 11 * (mass w + 4) + 16
      grind

theorem block_area_upper_sharp :
    4 * areaW ([true] ++ aasW) =
      5 * mass ([true] ++ aasW) * mass ([true] ++ aasW) - 11 * mass ([true] ++ aasW) + 16 := by
  decide

theorem block_prefix_area_quadratic_upper (f : Nat → Bool) (n a t : Nat)
    {β : List Bool} (hβ : BlockWord β)
    (hseg : seg f 0 n = β ++ List.replicate a true) (htn : t ≤ n) :
    4 * Ar f t (n-t) ≤
      5 * (Fw f n - Fw f t) * (Fw f n - Fw f t) - 11 * (Fw f n - Fw f t) + 16 := by
  have hfull : BlockWord (seg f 0 n) := by
    rw [hseg]
    exact block_append hβ (block_replicate_A a)
  have hsplit := suffix_split f 0 n t (Nat.zero_le _) (by omega)
  simp only [Nat.zero_add, Nat.sub_zero] at hsplit
  have hsuffix := block_suffix hfull (seg f 0 t) (seg f t (n-t)) hsplit.symm
  have hbound := block_area_quadratic_upper hsuffix
  simpa only [← Ar_areaW, seg_mass, show t + (n-t) = n by omega] using hbound

end Recaman.BlockSuffixPositivity
